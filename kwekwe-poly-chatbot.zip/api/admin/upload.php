<?php

declare(strict_types=1);

require_once __DIR__ . '/../../app/bootstrap.php';

kwekwe_handle_preflight();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    kwekwe_method_not_allowed('POST, OPTIONS');
}

kwekwe_require_admin();
kwekwe_json_response(kwekwe_admin_upload_documents($_FILES));
