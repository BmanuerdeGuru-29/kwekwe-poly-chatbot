<?php

declare(strict_types=1);

require_once __DIR__ . '/chat.php';

if (!function_exists('kwekwe_start_session')) {
    function kwekwe_start_session(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        session_name('kwekwe_admin');
        session_start([
            'cookie_httponly' => true,
            'cookie_samesite' => 'Lax',
            'use_strict_mode' => true,
        ]);
    }
}

if (!function_exists('kwekwe_is_admin')) {
    function kwekwe_is_admin(): bool
    {
        kwekwe_start_session();
        return !empty($_SESSION['kwekwe_admin_authenticated']);
    }
}

if (!function_exists('kwekwe_require_admin')) {
    function kwekwe_require_admin(): void
    {
        if (!kwekwe_is_admin()) {
            kwekwe_json_response([
                'authenticated' => false,
                'login_required' => true,
                'detail' => 'Admin sign-in required.',
            ], 401);
        }
    }
}

if (!function_exists('kwekwe_admin_login')) {
    function kwekwe_admin_login(string $key): array
    {
        kwekwe_start_session();
        if (!hash_equals(kwekwe_config()['admin_key'], trim($key))) {
            return [
                'authenticated' => false,
                'detail' => 'Invalid admin key.',
            ];
        }

        $_SESSION['kwekwe_admin_authenticated'] = true;
        $_SESSION['kwekwe_admin_issued_at'] = time();

        return kwekwe_admin_session_state();
    }
}

if (!function_exists('kwekwe_admin_logout')) {
    function kwekwe_admin_logout(): array
    {
        kwekwe_start_session();
        $_SESSION = [];
        session_destroy();

        return [
            'authenticated' => false,
            'detail' => 'Admin session cleared.',
        ];
    }
}

if (!function_exists('kwekwe_admin_session_state')) {
    function kwekwe_admin_session_state(): array
    {
        kwekwe_start_session();
        $authenticated = kwekwe_is_admin();

        return [
            'authenticated' => $authenticated,
            'method' => $authenticated ? 'php-session' : null,
            'issued_at' => isset($_SESSION['kwekwe_admin_issued_at'])
                ? gmdate('c', (int) $_SESSION['kwekwe_admin_issued_at'])
                : null,
            'login_required' => !$authenticated,
        ];
    }
}

if (!function_exists('kwekwe_admin_analytics_summary')) {
    function kwekwe_admin_analytics_summary(): array
    {
        $events = kwekwe_read_jsonl(kwekwe_config()['storage']['analytics']);
        $intentCounts = [];
        $languages = [];

        foreach ($events as $event) {
            $intent = $event['intent'] ?? 'general';
            $language = $event['language'] ?? 'en';
            $intentCounts[$intent] = ($intentCounts[$intent] ?? 0) + 1;
            $languages[$language] = ($languages[$language] ?? 0) + 1;
        }

        arsort($intentCounts);
        arsort($languages);

        return [
            'status' => 'ok',
            'total_queries' => count($events),
            'intent_breakdown' => $intentCounts,
            'language_breakdown' => $languages,
            'recent_queries' => array_slice(array_reverse($events), 0, 10),
        ];
    }
}

if (!function_exists('kwekwe_admin_recent_feedback')) {
    function kwekwe_admin_recent_feedback(int $limit = 25): array
    {
        $records = kwekwe_read_jsonl(kwekwe_config()['storage']['feedback']);
        return array_slice(array_reverse($records), 0, $limit);
    }
}

if (!function_exists('kwekwe_admin_documents')) {
    function kwekwe_admin_documents(): array
    {
        $index = kwekwe_load_knowledge_index();
        return [
            'generated_at' => $index['generated_at'] ?? null,
            'document_count' => $index['document_count'] ?? 0,
            'chunk_count' => $index['chunk_count'] ?? 0,
            'documents' => $index['documents'] ?? [],
        ];
    }
}

if (!function_exists('kwekwe_admin_rebuild_index')) {
    function kwekwe_admin_rebuild_index(): array
    {
        $index = kwekwe_save_knowledge_index(kwekwe_build_knowledge_index());
        return [
            'status' => 'ok',
            'detail' => 'Knowledge index rebuilt successfully.',
            'generated_at' => $index['generated_at'],
            'document_count' => $index['document_count'],
            'chunk_count' => $index['chunk_count'],
        ];
    }
}

if (!function_exists('kwekwe_admin_upload_documents')) {
    function kwekwe_admin_upload_documents(array $files): array
    {
        $uploaded = [];
        $targetDirectory = kwekwe_path('storage', 'uploads');
        kwekwe_ensure_directory($targetDirectory);

        $fileBag = $files['documents'] ?? $files['documents[]'] ?? null;

        if ($fileBag === null) {
            return [
                'status' => 'error',
                'detail' => 'No files uploaded.',
                'uploaded' => [],
            ];
        }

        $names = (array) ($fileBag['name'] ?? []);
        $tmpNames = (array) ($fileBag['tmp_name'] ?? []);
        $errors = (array) ($fileBag['error'] ?? []);

        foreach ($names as $index => $name) {
            $error = $errors[$index] ?? UPLOAD_ERR_NO_FILE;
            if ($error !== UPLOAD_ERR_OK) {
                continue;
            }

            $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (!in_array($extension, ['md', 'txt'], true)) {
                continue;
            }

            $safeName = kwekwe_slugify(pathinfo($name, PATHINFO_FILENAME)) . '.' . $extension;
            $destination = $targetDirectory . DIRECTORY_SEPARATOR . $safeName;
            move_uploaded_file((string) $tmpNames[$index], $destination);

            $uploaded[] = [
                'filename' => $safeName,
                'path' => 'storage/uploads/' . $safeName,
            ];
        }

        $rebuild = kwekwe_admin_rebuild_index();

        return [
            'status' => 'ok',
            'detail' => $uploaded === [] ? 'No valid files were uploaded.' : 'Files uploaded and indexed.',
            'uploaded' => $uploaded,
            'index' => $rebuild,
        ];
    }
}
