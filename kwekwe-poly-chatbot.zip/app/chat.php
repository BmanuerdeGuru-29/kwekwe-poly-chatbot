<?php

declare(strict_types=1);

require_once __DIR__ . '/knowledge.php';

if (!function_exists('kwekwe_detect_intent')) {
    function kwekwe_detect_intent(string $message): string
    {
        $text = kwekwe_normalize_text($message);

        return match (true) {
            preg_match('/fee|payment|cost|tuition|bank|ecocash|onemoney|paynow/u', $text) === 1 => 'fees',
            preg_match('/apply|application|admission|intake|requirement|register/u', $text) === 1 => 'admissions',
            preg_match('/engineering|automotive|mechanical|electrical|civil/u', $text) === 1 => 'engineering',
            preg_match('/commerce|business|management|accountancy|banking|finance/u', $text) === 1 => 'commerce',
            preg_match('/applied science|information technology|biological|physical science|metallurgy/u', $text) === 1 => 'applied_sciences',
            preg_match('/btech|b tech|degree|industrial and manufacturing|electrical power/u', $text) === 1 => 'btech',
            preg_match('/adult|continuing education|ace|cosmetology|tourism|textile/u', $text) === 1 => 'ace',
            preg_match('/portal|elearning|e learning|ict|password|login/u', $text) === 1 => 'portal',
            preg_match('/hostel|accommodation|welfare|student affairs/u', $text) === 1 => 'accommodation',
            preg_match('/hexco|exam|result|examination|certificate/u', $text) === 1 => 'exams',
            preg_match('/contact|phone|email|whatsapp|office/u', $text) === 1 => 'contact',
            default => 'general',
        };
    }
}

if (!function_exists('kwekwe_default_actions')) {
    function kwekwe_default_actions(): array
    {
        $links = kwekwe_config()['links'];

        return [
            ['label' => 'Apply Online', 'type' => 'link', 'url' => $links['apply']],
            ['label' => 'Portal Help', 'type' => 'prompt', 'prompt' => 'How do I access the student portal and get ICT help?'],
            ['label' => 'Fees Guide', 'type' => 'prompt', 'prompt' => 'Show me the fee payment options in USD and ZiG.'],
        ];
    }
}

if (!function_exists('kwekwe_actions_for_intent')) {
    function kwekwe_actions_for_intent(string $intent): array
    {
        $links = kwekwe_config()['links'];

        return match ($intent) {
            'fees' => [
                ['label' => 'Apply Online', 'type' => 'link', 'url' => $links['apply']],
                ['label' => 'Admissions', 'type' => 'prompt', 'prompt' => 'What documents do I need to apply?'],
            ],
            'portal' => [
                ['label' => 'Open Portal', 'type' => 'link', 'url' => $links['portal']],
                ['label' => 'ICT Help', 'type' => 'prompt', 'prompt' => 'How do I get ICT help for the student portal?'],
            ],
            'accommodation' => [
                ['label' => 'Hostel Page', 'type' => 'link', 'url' => $links['hostel']],
                ['label' => 'Student Affairs', 'type' => 'prompt', 'prompt' => 'How do I contact student affairs about accommodation?'],
            ],
            default => kwekwe_default_actions(),
        };
    }
}

if (!function_exists('kwekwe_handoff_for_intent')) {
    function kwekwe_handoff_for_intent(string $intent): ?array
    {
        $contacts = kwekwe_config()['contacts'];

        return match ($intent) {
            'portal' => [
                'office' => 'ICT Support',
                'message' => "Use the student portal and official ICT support channels for account-specific issues.\n- Portal: " . kwekwe_config()['links']['portal'] . "\n- Phone: {$contacts['phone']}\n- Email: {$contacts['email']}",
            ],
            'accommodation' => [
                'office' => 'Student Affairs',
                'message' => "Accommodation is limited, so confirm the latest availability and charges with Student Affairs before paying.\n- Hostel page: " . kwekwe_config()['links']['hostel'] . "\n- Phone: {$contacts['phone']}\n- WhatsApp: {$contacts['whatsapp']}",
            ],
            'admissions', 'fees' => [
                'office' => 'Admissions and Accounts',
                'message' => "Use the official application and accounts channels for the latest deadlines, balances, and payment confirmations.\n- Apply: " . kwekwe_config()['links']['apply'] . "\n- Phone: {$contacts['phone']}\n- Email: {$contacts['email']}",
            ],
            default => null,
        };
    }
}

if (!function_exists('kwekwe_extract_points')) {
    function kwekwe_extract_points(array $results, int $limit = 5): array
    {
        $points = [];

        foreach ($results as $result) {
            $lines = preg_split("/\R/u", (string) ($result['content'] ?? '')) ?: [];
            foreach ($lines as $line) {
                $clean = trim($line);
                $clean = preg_replace('/^[-*#\d\.\)\s]+/u', '', $clean) ?? $clean;
                $length = function_exists('mb_strlen') ? mb_strlen($clean, 'UTF-8') : strlen($clean);
                if ($clean === '' || $length < 18) {
                    continue;
                }

                $key = kwekwe_normalize_text($clean);
                if (isset($points[$key])) {
                    continue;
                }

                $points[$key] = rtrim($clean, '. ') . '.';
                if (count($points) >= $limit) {
                    break 2;
                }
            }
        }

        return array_values($points);
    }
}

if (!function_exists('kwekwe_compose_answer')) {
    function kwekwe_compose_answer(string $intent, array $results): string
    {
        $contacts = kwekwe_config()['contacts'];
        $links = kwekwe_config()['links'];

        if ($results === []) {
            return "I could not find a strong local match for that in the offline knowledge base.\n\n"
                . "The safest next step is to use the official Kwekwe Polytechnic channels:\n"
                . "- Website: {$links['website']}\n"
                . "- Apply portal: {$links['apply']}\n"
                . "- Student portal: {$links['portal']}\n"
                . "- Phone: {$contacts['phone']}\n"
                . "- WhatsApp: {$contacts['whatsapp']}\n"
                . "- Email: {$contacts['email']}";
        }

        $intro = match ($intent) {
            'fees' => 'Here is the closest fee and payment guidance I found in the local Kwekwe Polytechnic knowledge base:',
            'admissions' => 'Here is the admissions guidance I found in the local Kwekwe Polytechnic knowledge base:',
            'engineering' => 'Here is the engineering information I found in the local Kwekwe Polytechnic knowledge base:',
            'commerce' => 'Here is the commerce information I found in the local Kwekwe Polytechnic knowledge base:',
            'applied_sciences' => 'Here is the applied sciences information I found in the local Kwekwe Polytechnic knowledge base:',
            'btech' => 'Here is the B-Tech guidance I found in the local Kwekwe Polytechnic knowledge base:',
            'ace' => 'Here is the Adult and Continuing Education guidance I found in the local Kwekwe Polytechnic knowledge base:',
            'portal' => 'Here is the portal and ICT guidance I found in the local Kwekwe Polytechnic knowledge base:',
            'accommodation' => 'Here is the accommodation guidance I found in the local Kwekwe Polytechnic knowledge base:',
            'exams' => 'Here is the examination and HEXCO guidance I found in the local Kwekwe Polytechnic knowledge base:',
            'contact' => 'Here are the main contact details I found in the local Kwekwe Polytechnic knowledge base:',
            default => 'Here is the closest match I found in the local Kwekwe Polytechnic knowledge base:',
        };

        $lines = [$intro, ''];
        foreach (kwekwe_extract_points($results, 5) as $point) {
            $lines[] = '- ' . $point;
        }

        if (in_array($intent, ['fees', 'admissions', 'accommodation', 'portal', 'exams'], true)) {
            $lines[] = '';
            $lines[] = 'Official follow-up channels:';
            $lines[] = '- Website: ' . $links['website'];
            $lines[] = '- Apply portal: ' . $links['apply'];
            $lines[] = '- Phone: ' . $contacts['phone'];
            $lines[] = '- Email: ' . $contacts['email'];
        }

        return implode("\n", $lines);
    }
}

if (!function_exists('kwekwe_chat_sources')) {
    function kwekwe_chat_sources(array $results): array
    {
        $sources = [];
        foreach (array_slice($results, 0, 3) as $result) {
            $sources[] = [
                'title' => $result['title'] ?? 'Knowledge source',
                'excerpt' => $result['excerpt'] ?? '',
                'metadata' => $result['metadata'] ?? [],
            ];
        }

        return $sources;
    }
}

if (!function_exists('kwekwe_record_chat_event')) {
    function kwekwe_record_chat_event(array $event): void
    {
        kwekwe_append_jsonl(kwekwe_config()['storage']['analytics'], $event);
    }
}

if (!function_exists('kwekwe_build_chat_response')) {
    function kwekwe_build_chat_response(array $request): array
    {
        $message = trim((string) ($request['message'] ?? ''));
        if ($message === '') {
            return ['error' => 'Message cannot be empty'];
        }

        $message = function_exists('mb_substr') ? mb_substr($message, 0, 1200, 'UTF-8') : substr($message, 0, 1200);
        $sessionId = trim((string) ($request['session_id'] ?? '')) ?: kwekwe_random_session_id();
        $language = trim((string) ($request['language'] ?? 'en')) ?: 'en';
        $intent = kwekwe_detect_intent($message);
        $results = kwekwe_search_knowledge($message, 6, $intent);
        $answer = kwekwe_compose_answer($intent, $results);
        $topScore = $results[0]['score'] ?? 0.0;

        $payload = [
            'response' => $answer,
            'session_id' => $sessionId,
            'sources' => kwekwe_chat_sources($results),
            'confidence' => [
                'score' => $topScore,
                'label' => $topScore >= 10 ? 'high' : ($topScore >= 6 ? 'medium' : 'low'),
            ],
            'handoff' => kwekwe_handoff_for_intent($intent),
            'suggested_actions' => kwekwe_actions_for_intent($intent),
            'language' => $language,
            'intent' => $intent,
            'timestamp' => kwekwe_current_timestamp(),
            'query_type' => $results === [] ? 'fallback' : 'local-search',
        ];

        kwekwe_record_chat_event([
            'timestamp' => $payload['timestamp'],
            'session_id' => $sessionId,
            'intent' => $intent,
            'language' => $language,
            'query' => $message,
            'result_count' => count($results),
            'top_score' => $topScore,
        ]);

        return $payload;
    }
}

if (!function_exists('kwekwe_record_feedback')) {
    function kwekwe_record_feedback(array $payload): array
    {
        $record = [
            'timestamp' => kwekwe_current_timestamp(),
            'session_id' => trim((string) ($payload['session_id'] ?? '')),
            'message_content' => trim((string) ($payload['message_content'] ?? '')),
            'helpful' => (bool) ($payload['helpful'] ?? false),
            'comment' => trim((string) ($payload['comment'] ?? '')),
            'intent' => trim((string) ($payload['intent'] ?? 'general')) ?: 'general',
        ];

        kwekwe_append_jsonl(kwekwe_config()['storage']['feedback'], $record);
        return $record;
    }
}
