<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';

if (!function_exists('kwekwe_detect_source_category')) {
    function kwekwe_detect_source_category(string $filename): string
    {
        $filename = strtolower($filename);
        return match (true) {
            str_contains($filename, 'fee') || str_contains($filename, 'admission') => 'fees',
            str_contains($filename, 'engineering') => 'engineering',
            str_contains($filename, 'commerce') => 'commerce',
            str_contains($filename, 'applied') => 'applied_sciences',
            str_contains($filename, 'btech') => 'btech',
            str_contains($filename, 'ace') => 'ace',
            str_contains($filename, 'hexco') || str_contains($filename, 'exam') => 'exams',
            default => 'general',
        };
    }
}

if (!function_exists('kwekwe_source_url_for_category')) {
    function kwekwe_source_url_for_category(string $category): ?string
    {
        $links = kwekwe_config()['links'];

        return match ($category) {
            'fees' => $links['apply'],
            default => $links['website'],
        };
    }
}

if (!function_exists('kwekwe_list_source_files')) {
    function kwekwe_list_source_files(): array
    {
        $paths = [];
        foreach (kwekwe_config()['knowledge_sources'] as $directory) {
            if (!is_dir($directory)) {
                continue;
            }

            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS)
            );

            foreach ($iterator as $item) {
                if (!$item instanceof SplFileInfo || !$item->isFile()) {
                    continue;
                }

                $extension = strtolower($item->getExtension());
                if (!in_array($extension, ['md', 'txt'], true)) {
                    continue;
                }

                $paths[] = $item->getPathname();
            }
        }

        sort($paths);
        return $paths;
    }
}

if (!function_exists('kwekwe_parse_markdown_sections')) {
    function kwekwe_parse_markdown_sections(string $content): array
    {
        $lines = preg_split("/\R/u", $content) ?: [];
        $sections = [];
        $currentHeading = 'Overview';
        $buffer = [];

        foreach ($lines as $line) {
            $trimmed = trim($line);
            if (preg_match('/^#{1,3}\s+(.+)$/u', $trimmed, $matches)) {
                if (trim(implode("\n", $buffer)) !== '') {
                    $sections[] = [
                        'heading' => $currentHeading,
                        'content' => trim(implode("\n", $buffer)),
                    ];
                }
                $currentHeading = trim($matches[1]);
                $buffer = [];
                continue;
            }

            $buffer[] = $line;
        }

        if (trim(implode("\n", $buffer)) !== '') {
            $sections[] = [
                'heading' => $currentHeading,
                'content' => trim(implode("\n", $buffer)),
            ];
        }

        return array_values(array_filter($sections, static function (array $section): bool {
            $content = trim($section['content']);
            $length = function_exists('mb_strlen') ? mb_strlen($content, 'UTF-8') : strlen($content);
            return $length >= 40;
        }));
    }
}

if (!function_exists('kwekwe_build_knowledge_index')) {
    function kwekwe_build_knowledge_index(): array
    {
        $documents = [];
        $chunks = [];

        foreach (kwekwe_list_source_files() as $path) {
            $content = trim((string) file_get_contents($path));
            if ($content === '') {
                continue;
            }

            $relativePath = str_replace(kwekwe_project_root() . DIRECTORY_SEPARATOR, '', $path);
            $filename = basename($path);
            preg_match('/^#\s+(.+)$/m', $content, $titleMatch);
            $title = $titleMatch[1] ?? ucwords(str_replace(['_', '-'], ' ', pathinfo($filename, PATHINFO_FILENAME)));
            $category = kwekwe_detect_source_category($filename);
            $documentId = kwekwe_slugify(pathinfo($filename, PATHINFO_FILENAME));

            $documents[] = [
                'id' => $documentId,
                'title' => $title,
                'category' => $category,
                'source_path' => $relativePath,
                'source_url' => kwekwe_source_url_for_category($category),
            ];

            $sectionIndex = 0;
            foreach (kwekwe_parse_markdown_sections($content) as $section) {
                $sectionIndex++;
                $chunks[] = [
                    'id' => $documentId . '-' . $sectionIndex,
                    'document_id' => $documentId,
                    'title' => $title,
                    'category' => $category,
                    'heading' => $section['heading'],
                    'content' => $section['content'],
                    'excerpt' => kwekwe_excerpt($section['content'], 220),
                    'tokens' => kwekwe_tokenize($title . ' ' . $section['heading'] . ' ' . $section['content']),
                    'metadata' => [
                        'filename' => $filename,
                        'source_path' => $relativePath,
                        'source_url' => kwekwe_source_url_for_category($category),
                    ],
                ];
            }
        }

        return [
            'generated_at' => kwekwe_current_timestamp(),
            'document_count' => count($documents),
            'chunk_count' => count($chunks),
            'documents' => $documents,
            'chunks' => $chunks,
        ];
    }
}

if (!function_exists('kwekwe_save_knowledge_index')) {
    function kwekwe_save_knowledge_index(array $index): array
    {
        kwekwe_write_json_file(kwekwe_config()['knowledge_index'], $index);
        return $index;
    }
}

if (!function_exists('kwekwe_load_knowledge_index')) {
    function kwekwe_load_knowledge_index(bool $refresh = false): array
    {
        static $cache = null;

        if ($refresh || $cache === null) {
            $indexPath = kwekwe_config()['knowledge_index'];
            $cache = $refresh || !is_file($indexPath)
                ? kwekwe_save_knowledge_index(kwekwe_build_knowledge_index())
                : kwekwe_read_json_file($indexPath, []);

            if (!isset($cache['chunks']) || !is_array($cache['chunks'])) {
                $cache = kwekwe_save_knowledge_index(kwekwe_build_knowledge_index());
            }
        }

        return $cache;
    }
}

if (!function_exists('kwekwe_search_knowledge')) {
    function kwekwe_search_knowledge(string $query, int $limit = 5, ?string $intent = null): array
    {
        $queryTokens = kwekwe_tokenize($query);
        if ($queryTokens === []) {
            return [];
        }

        $normalizedQuery = kwekwe_normalize_text($query);
        $index = kwekwe_load_knowledge_index();
        $results = [];

        foreach ($index['chunks'] ?? [] as $chunk) {
            $score = 0.0;
            $haystack = kwekwe_normalize_text(
                ($chunk['title'] ?? '') . ' ' . ($chunk['heading'] ?? '') . ' ' . ($chunk['content'] ?? '')
            );

            if ($normalizedQuery !== '' && str_contains($haystack, $normalizedQuery)) {
                $score += 8.0;
            }

            foreach ($queryTokens as $token) {
                if (str_contains($haystack, $token)) {
                    $score += 2.2;
                }
                if (str_contains(kwekwe_normalize_text((string) $chunk['heading']), $token)) {
                    $score += 1.8;
                }
                if (str_contains(kwekwe_normalize_text((string) $chunk['title']), $token)) {
                    $score += 1.2;
                }
            }

            if ($intent !== null && $intent !== 'general' && ($chunk['category'] ?? '') === $intent) {
                $score += 3.5;
            }

            if ($score <= 0) {
                continue;
            }

            $result = $chunk;
            $result['score'] = round($score, 3);
            $results[] = $result;
        }

        usort($results, static function (array $left, array $right): int {
            return $right['score'] <=> $left['score'];
        });

        return array_values(array_slice($results, 0, max(1, $limit)));
    }
}
